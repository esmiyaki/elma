"""Vehicle model for a small Ackermann-steered car.

The state is represented at the *geometric centre* of the car body
(x, y, theta). Internally the kinematic bicycle model is integrated at
the rear axle, so the conversion is applied for every step. This keeps
the user-facing position intuitive (the centre of the rectangle the
user sees) while preserving the standard kinematic equations.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


CAR_LENGTH = 31.0     # cm  – body length along the heading
CAR_WIDTH = 18.0      # cm  – body width perpendicular to heading
WHEELBASE = 16.0      # cm  – distance between front and rear axles
MAX_STEER = math.radians(25.0)            # physical steering limit

# Planning-side kinematics tolerance: the planner may only command up to
# ``1 - PLANNING_STEER_MARGIN`` of the physical steering range. With a 10 %
# margin the *planned* min turn radius becomes ``WHEELBASE / tan(MAX_STEER * 0.9)``
# (≈ 38.0 cm instead of ≈ 34.3 cm), giving a small safety buffer against
# actuator slop, tyre slip, and discretisation error.
PLANNING_STEER_MARGIN = 0.10
PLANNING_MAX_STEER = MAX_STEER * (1.0 - PLANNING_STEER_MARGIN)
MIN_TURN_RADIUS_PHYSICAL = WHEELBASE / math.tan(MAX_STEER)
MIN_TURN_RADIUS_PLANNING = WHEELBASE / math.tan(PLANNING_MAX_STEER)

# Half-extents used everywhere for the body rectangle.
HALF_L = CAR_LENGTH / 2.0
HALF_W = CAR_WIDTH / 2.0


@dataclass(frozen=True)
class Pose:
    x: float
    y: float
    theta: float

    def as_tuple(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.theta)


def normalize_angle(a: float) -> float:
    """Wrap angle to (-pi, pi]."""
    a = (a + math.pi) % (2.0 * math.pi) - math.pi
    return a


def car_corners(x: float, y: float, theta: float) -> list[tuple[float, float]]:
    """Return the four corners of the car footprint (world coords)."""
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    corners = []
    for dx, dy in (
        (HALF_L, HALF_W),
        (HALF_L, -HALF_W),
        (-HALF_L, -HALF_W),
        (-HALF_L, HALF_W),
    ):
        cx = x + dx * cos_t - dy * sin_t
        cy = y + dx * sin_t + dy * cos_t
        corners.append((cx, cy))
    return corners


def step_state(
    state: tuple[float, float, float],
    direction: int,
    steer: float,
    arc_length: float,
    substeps: int = 5,
) -> tuple[float, float, float]:
    """Advance the centre-state by ``arc_length`` cm.

    ``direction`` is +1 (forward) or -1 (reverse). ``steer`` is the front
    wheel angle in radians (clamped to ``MAX_STEER``). The kinematic
    bicycle model is integrated at the rear axle in ``substeps`` Euler
    sub-steps; the result is converted back to the centre.
    """
    steer = max(-MAX_STEER, min(MAX_STEER, steer))

    # Convert centre -> rear axle.
    cx, cy, theta = state
    rx = cx - (WHEELBASE / 2.0) * math.cos(theta)
    ry = cy - (WHEELBASE / 2.0) * math.sin(theta)

    ds = direction * arc_length / substeps
    tan_steer = math.tan(steer)
    for _ in range(substeps):
        rx += ds * math.cos(theta)
        ry += ds * math.sin(theta)
        theta += ds * tan_steer / WHEELBASE

    theta = normalize_angle(theta)
    cx = rx + (WHEELBASE / 2.0) * math.cos(theta)
    cy = ry + (WHEELBASE / 2.0) * math.sin(theta)
    return (cx, cy, theta)


def interpolate_states(
    state: tuple[float, float, float],
    direction: int,
    steer: float,
    arc_length: float,
    samples: int = 6,
) -> list[tuple[float, float, float]]:
    """Return ``samples`` intermediate poses along one motion primitive.

    The returned list does *not* include the starting state; it always
    contains exactly ``samples`` poses ending at the final state. Used
    both for collision checking along the arc and for drawing the path.
    """
    sub_arc = arc_length / samples
    poses: list[tuple[float, float, float]] = []
    cur = state
    for _ in range(samples):
        cur = step_state(cur, direction, steer, sub_arc, substeps=2)
        poses.append(cur)
    return poses
