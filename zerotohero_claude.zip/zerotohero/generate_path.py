"""Plan a path to a parking slot and save it as `planned_path.json`.

Pipeline
--------
1. Read the current pose from ``apriltag_pose.AprilTagMapPoseTracker``.
   The tracker returns the **front-axle** position in map coordinates
   (``x_cm``, ``y_cm``, ``yaw_deg``).
2. Convert front axle -> car centre (planner expects centre-frame poses).
3. Build a goal pose at the parking-slot centre, plus an *approach* pose
   located 40 cm before the slot along the slot's heading.
4. Run Hybrid A* from the start (centre) to the approach pose.
5. Append a 40 cm dead-straight segment from approach -> slot centre
   (always forward, steer = 0).
6. Write all path samples to ``planned_path.json`` in **centre frame**.
   The controller is responsible for shifting these to the front/rear
   axle when computing CTE.

JSON shape
----------
::

    {
      "metadata": {...},
      "points": [
          {"x_cm": ..., "y_cm": ..., "yaw_rad": ...,
           "direction": +1|-1, "steer_rad": ...},
          ...
      ]
    }
"""

from __future__ import annotations

import argparse
import json
import math
import time
from typing import Iterable, List, Sequence, Tuple

from apriltag_pose import AprilTagMapPoseTracker
from planner import PathSegment, PlanResult, plan
from vehicle import WHEELBASE, normalize_angle


# Parking-slot table (id, centre_x_cm, centre_y_cm, yaw_rad).
# Yaw convention matches the planner: 0 rad = +X (east), CCW positive.
# (cx, cy, yaw) is exactly the car-centre + heading we target when this
# slot is the goal. Mirrors ``main.py:PARKING_SLOTS`` -- duplicated here
# so this script does not need to import the pygame-based UI module.
PARKING_SLOTS: List[Tuple[int, float, float, float]] = [
    (1,  112.5, 180.0,  math.pi / 2),
    (2,  180.0, 137.5,  0.0),
    (3,  180.0, 112.5,  0.0),
    (4,  180.0,  87.5,  0.0),
    (5,  180.0,  62.5,  0.0),
    (6,  112.5,  20.0, -math.pi / 2),
    (7,   87.5,  20.0, -math.pi / 2),
    (8,   20.0,  62.5,  math.pi),
    (9,   20.0,  87.5,  math.pi),
    (10,  20.0, 112.5,  math.pi),
    (11,  20.0, 137.5,  math.pi),
    (12,  87.5, 180.0,  math.pi / 2),
]

APPROACH_OFFSET_CM = 40.0      # distance before slot centre we aim for first
STRAIGHT_DENSITY_CM = 1.0      # spacing of samples in the final straight 40 cm
PLANNER_STEP_SIZE = 4.0        # default step size for Hybrid A*
POSE_TIMEOUT_S = 10.0          # how long we wait for the first AprilTag fix


# ----- frame conversions ---------------------------------------------------

def front_axle_to_centre(x_front: float, y_front: float, yaw_rad: float) -> Tuple[float, float]:
    """Shift front-axle pose back to the car centre (planner frame)."""
    half_wb = WHEELBASE / 2.0
    return (
        x_front - half_wb * math.cos(yaw_rad),
        y_front - half_wb * math.sin(yaw_rad),
    )


def yaw_deg_to_planner_rad(yaw_deg: float) -> float:
    """Map AprilTag's map-frame yaw_deg to the planner's yaw_rad.

    Matches ``benjiereverseimprovement.py``: ``yaw_rad = yaw_deg + 90°``
    so that the apriltag's "north-aligned 0°" lines up with the planner's
    +Y heading (``pi/2`` rad).
    """
    return normalize_angle(math.radians(float(yaw_deg)) + math.pi / 2.0)


# ----- pose acquisition ----------------------------------------------------

def acquire_start_pose_centre(timeout_s: float = POSE_TIMEOUT_S) -> Tuple[float, float, float]:
    """Open the tracker, wait for one valid fix, return start pose in centre frame."""
    tracker = AprilTagMapPoseTracker()
    deadline = time.perf_counter() + float(timeout_s)
    try:
        while time.perf_counter() < deadline:
            p = tracker.update()
            if p is None:
                time.sleep(0.05)
                continue
            yaw_rad = yaw_deg_to_planner_rad(p["yaw_deg"])
            xc, yc = front_axle_to_centre(float(p["x_cm"]), float(p["y_cm"]), yaw_rad)
            return (xc, yc, yaw_rad)
    finally:
        tracker.close()
    raise RuntimeError(f"AprilTag pose not detected within {timeout_s:.1f}s.")


# ----- path-point assembly -------------------------------------------------

def _segment_directions(poses: Sequence[Tuple[float, float, float]],
                        segments: Sequence[PathSegment]) -> List[int]:
    """Per-pose direction array aligned with ``poses``.

    Each segment's ``poses[0]`` is the seam shared with the previous
    segment, and ``poses[1:]`` are the new arc poses contributed by this
    segment, so we can walk segments and stamp the direction onto each
    new pose.
    """
    dirs = [1] * len(poses)
    if not segments:
        return dirs
    dirs[0] = int(segments[0].direction)
    idx = 1
    for seg in segments:
        n_new = len(seg.poses) - 1
        d = int(seg.direction)
        for _ in range(n_new):
            if idx < len(dirs):
                dirs[idx] = d
                idx += 1
    return dirs


def _approx_steer_rad(prev: Tuple[float, float, float],
                      curr: Tuple[float, float, float],
                      direction: int) -> float:
    """Approximate the bicycle-model steer angle that connects two poses.

    From ``d theta = (signed_arc / WB) * tan(steer)`` we get
    ``steer = atan2(d theta * WB, signed_arc)``. Good enough as a
    feed-forward hint for the controller.
    """
    dx = curr[0] - prev[0]
    dy = curr[1] - prev[1]
    chord = math.hypot(dx, dy)
    if chord < 1e-9:
        return 0.0
    signed = chord * (1.0 if direction >= 0 else -1.0)
    dtheta = normalize_angle(curr[2] - prev[2])
    return math.atan2(dtheta * WHEELBASE, signed)


def build_path_points(plan_result: PlanResult,
                      approach_pose: Tuple[float, float, float],
                      goal_pose: Tuple[float, float, float]) -> List[dict]:
    """Convert a planner result + final straight segment into JSON points (centre frame)."""
    poses = list(plan_result.poses)
    dirs = _segment_directions(poses, plan_result.segments)

    points: List[dict] = []
    for i, pose in enumerate(poses):
        x, y, th = pose
        if i == 0:
            steer = 0.0
        else:
            steer = _approx_steer_rad(poses[i - 1], pose, dirs[i])
        points.append({
            "x_cm": float(x),
            "y_cm": float(y),
            "yaw_rad": float(normalize_angle(th)),
            "direction": int(dirs[i]),
            "steer_rad": float(steer),
        })

    # 40 cm dead-straight forward segment from approach -> goal.
    ax, ay, _ = approach_pose
    gx, gy, gyaw = goal_pose
    n_straight = max(2, int(math.ceil(APPROACH_OFFSET_CM / STRAIGHT_DENSITY_CM)))
    for k in range(1, n_straight + 1):
        u = k / n_straight
        points.append({
            "x_cm": float(ax + u * (gx - ax)),
            "y_cm": float(ay + u * (gy - ay)),
            "yaw_rad": float(normalize_angle(gyaw)),
            "direction": 1,
            "steer_rad": 0.0,
        })
    return points


# ----- glue ----------------------------------------------------------------

def get_slot(slot_id: int) -> Tuple[int, float, float, float]:
    for s in PARKING_SLOTS:
        if s[0] == slot_id:
            return s
    raise ValueError(f"Unknown parking slot id {slot_id}.")


def parse_obstacles(spec: str) -> List[Tuple[float, float]]:
    if not spec:
        return []
    raw = json.loads(spec)
    return [(float(o[0]), float(o[1])) for o in raw]


def plan_to_slot(slot_id: int,
                 obstacles: Iterable[Tuple[float, float]] = (),
                 step_size: float = PLANNER_STEP_SIZE,
                 out_path: str = "planned_path.json") -> dict:
    sid, gx, gy, gyaw = get_slot(slot_id)
    approach_pose = (
        gx - APPROACH_OFFSET_CM * math.cos(gyaw),
        gy - APPROACH_OFFSET_CM * math.sin(gyaw),
        gyaw,
    )
    goal_pose = (gx, gy, gyaw)

    print("Acquiring AprilTag pose...")
    start_pose = acquire_start_pose_centre()
    print(
        f"Start (centre): x={start_pose[0]:.2f}, y={start_pose[1]:.2f}, "
        f"yaw={math.degrees(start_pose[2]):.1f}°"
    )
    print(
        f"Slot {sid} centre: x={gx:.2f}, y={gy:.2f}, "
        f"yaw={math.degrees(gyaw):.1f}°"
    )
    print(
        f"Approach: x={approach_pose[0]:.2f}, y={approach_pose[1]:.2f}, "
        f"yaw={math.degrees(approach_pose[2]):.1f}°"
    )

    print("Planning path to approach point...")
    obs_list = list(obstacles)
    result = plan(start_pose, approach_pose, obs_list, step_size)
    if not result.success:
        raise RuntimeError(f"Planner failed: {result.message}")
    relaxed = " [relaxed]" if result.relaxed else ""
    print(
        f"Planner OK: {len(result.poses)} poses, iter={result.iterations}, "
        f"time={result.elapsed*1000:.0f} ms{relaxed}"
    )

    points = build_path_points(result, approach_pose, goal_pose)
    out_obj = {
        "metadata": {
            "frame": "centre",
            "slot_id": sid,
            "start_pose_centre": list(start_pose),
            "approach_pose_centre": list(approach_pose),
            "goal_pose_centre": list(goal_pose),
            "approach_offset_cm": APPROACH_OFFSET_CM,
            "wheelbase_cm": WHEELBASE,
            "planner_step_cm": step_size,
            "obstacles_cm": [list(o) for o in obs_list],
            "n_points": len(points),
            "relaxed": bool(result.relaxed),
        },
        "points": points,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out_obj, f, indent=2)
    print(f"Wrote {len(points)} points to {out_path}.")
    return out_obj


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--slot", type=int, required=True, help="Parking slot ID (1..12).")
    parser.add_argument("--out", type=str, default="planned_path.json", help="Output JSON path.")
    parser.add_argument("--step", type=float, default=PLANNER_STEP_SIZE, help="Planner step size (cm).")
    parser.add_argument(
        "--obstacles",
        type=str,
        default="",
        help='JSON list of [x_cm, y_cm] obstacle centres, e.g. "[[60,100],[120,40]]".',
    )
    args = parser.parse_args()
    plan_to_slot(
        slot_id=args.slot,
        obstacles=parse_obstacles(args.obstacles),
        step_size=args.step,
        out_path=args.out,
    )


if __name__ == "__main__":
    main()
