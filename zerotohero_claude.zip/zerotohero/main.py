"""Pygame UI for the Hybrid A* planner.

Layout
------

* Left:  600 × 600 px canvas (3 px / cm) showing the 200 × 200 cm world.
* Right: 280 px control panel with mode toggles, step-size controls and
  Plan / Clear buttons.

Interaction
-----------

* **Set Start / Set Goal** – press the mouse button at the desired car
  position, drag in the heading direction, release to commit. While
  dragging, a preview of the pose is drawn live.
* **Add Obstacle** – click anywhere on the canvas to drop a 5 × 5 cm
  obstacle centred under the cursor. Snapping to a 1-cm grid avoids
  sub-pixel misalignment.
* **Erase Obstacle** – click on an existing obstacle to remove it.

Keyboard shortcuts: ``S`` start, ``G`` goal, ``O`` obstacle,
``E`` erase, ``P``/``Enter`` plan, ``C`` clear path, ``X`` clear all,
``-``/``+`` change step size, ``Space`` pause/play path animation.

The planned route is drawn in **green** (forward) and **red** (reverse).
A single car slides along that polyline; it is not duplicated at every
sample point.
"""

from __future__ import annotations

import bisect
import math
from typing import Optional

import pygame

from collision import (
    AREA_SIZE,
    OBSTACLE_HALF,
    OBSTACLE_SIZE,
    obstacle_at,
    state_is_valid,
)
from planner import PathSegment, PlanResult, plan
from vehicle import (
    CAR_LENGTH,
    CAR_WIDTH,
    HALF_L,
    HALF_W,
    WHEELBASE,
    car_corners,
)


# ----- window / world ------------------------------------------------------
SCALE = 3                                     # pixels per cm
CANVAS_PX = int(AREA_SIZE * SCALE)
SIDEBAR_PX = 290
WINDOW_W = CANVAS_PX + SIDEBAR_PX
WINDOW_H = CANVAS_PX

# ----- step size limits ---------------------------------------------------
STEP_MIN = 1.0
STEP_MAX = 15.0
STEP_INCR = 0.5
DEFAULT_STEP = 4.0

# Playback along the solved path (distance in cm along the polyline).
PLAYBACK_SPEED_CM_S = 40.0

# ----- parking slots ------------------------------------------------------
# Yaw convention:
#   0   rad = +X (east), CCW positive.
#   +pi/2 = +Y (north),  -pi/2 = -Y (south),  pi = -X (west).
# Each slot's (cx, cy, yaw) is exactly the car centre + heading the planner
# should target when that slot is picked as the goal.
SLOT_LENGTH = 40.0   # cm – slot extent along its yaw axis
SLOT_WIDTH = 25.0    # cm – slot extent perpendicular to yaw

PARKING_SLOTS: list[tuple[int, float, float, float]] = [
    (1,  112.5, 180.0,  math.pi / 2),
    (2,  180.0, 137.5,  0.0),
    (3,  180.0, 112.5,  0.0),
    (4,  180.0,  87.5,  0.0),
    (5,  180.0,  62.5,  0.0),
    (6,  112.5,  20.0, -math.pi / 2),
    (7,   87.5,  20.0, -math.pi / 2),
    (8,   20.0,  62.5,  math.pi),
    (9,   20.0,  87.5,  math.pi),
    (10,  20.0, 112.5,  math.pi),
    (11,  20.0, 137.5,  math.pi),
    (12,  87.5, 180.0,  math.pi / 2),
]

# ----- colours ------------------------------------------------------------
C_BG = (245, 246, 248)
C_PANEL = (228, 232, 240)
C_BORDER = (60, 70, 90)
C_GRID = (215, 220, 230)
C_AXIS = (130, 140, 160)
C_TEXT = (30, 35, 45)
C_TEXT_DIM = (90, 100, 115)
C_BUTTON = (255, 255, 255)
C_BUTTON_HOVER = (235, 240, 250)
C_BUTTON_ACTIVE = (90, 130, 220)
C_BUTTON_ACTIVE_TEXT = (255, 255, 255)
C_BUTTON_ACCENT = (50, 130, 70)
C_OBSTACLE = (60, 65, 80)
C_OBSTACLE_BORDER = (20, 22, 30)
C_START = (60, 120, 220)
C_GOAL = (210, 60, 70)
C_PATH_FWD = (40, 160, 80)
C_PATH_REV = (210, 45, 55)
C_DRAG = (120, 130, 160)
C_INVALID = (220, 80, 80)
C_ANIM_CAR = (245, 250, 255)
C_ANIM_CAR_BORDER = (55, 120, 150)
C_SLOT_FILL = (235, 244, 255)
C_SLOT_OUTLINE = (110, 155, 200)
C_SLOT_TEXT = (60, 95, 140)
C_SLOT_HOVER = (250, 230, 200)
C_SLOT_HOVER_OUTLINE = (235, 145, 35)
# Body fill ~45% opaque; outline and heading marker a bit stronger for readability.
ALPHA_SLIDE_BODY = 115
ALPHA_SLIDE_LINES = min(255, ALPHA_SLIDE_BODY + 85)
# Start / goal also let the path bleed through once a route is plotted.
ALPHA_POSE_BODY_OVER_PATH = 100
ALPHA_POSE_LINES_OVER_PATH = min(255, ALPHA_POSE_BODY_OVER_PATH + 85)


# ----- helpers ------------------------------------------------------------

def world_to_screen(x: float, y: float) -> tuple[int, int]:
    """World -> canvas pixel (origin bottom-left in world, top-left on screen)."""
    return int(round(x * SCALE)), int(round(CANVAS_PX - y * SCALE))


def screen_to_world(sx: int, sy: int) -> tuple[float, float]:
    return sx / SCALE, (CANVAS_PX - sy) / SCALE


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def slot_corners(cx: float, cy: float, yaw: float) -> list[tuple[float, float]]:
    """Four world-space corners of a parking slot (CCW)."""
    cos_y = math.cos(yaw)
    sin_y = math.sin(yaw)
    half_l = SLOT_LENGTH / 2.0
    half_w = SLOT_WIDTH / 2.0
    out = []
    for dl, dw in (
        (half_l,  half_w),
        (half_l, -half_w),
        (-half_l, -half_w),
        (-half_l,  half_w),
    ):
        out.append((
            cx + dl * cos_y - dw * sin_y,
            cy + dl * sin_y + dw * cos_y,
        ))
    return out


def slot_at(wx: float, wy: float) -> Optional[tuple[int, float, float, float]]:
    """Return the parking-slot tuple that contains the world point, or None."""
    half_l = SLOT_LENGTH / 2.0
    half_w = SLOT_WIDTH / 2.0
    for slot in PARKING_SLOTS:
        _id, cx, cy, yaw = slot
        cos_y = math.cos(yaw)
        sin_y = math.sin(yaw)
        dx = wx - cx
        dy = wy - cy
        # Project onto the slot's local axes.
        local_l = dx * cos_y + dy * sin_y
        local_w = -dx * sin_y + dy * cos_y
        if abs(local_l) <= half_l and abs(local_w) <= half_w:
            return slot
    return None


def draw_polygon_world(
    surf: pygame.Surface,
    color,
    corners: list[tuple[float, float]],
    width: int = 0,
) -> None:
    pts = [world_to_screen(x, y) for x, y in corners]
    pygame.draw.polygon(surf, color, pts, width)


def draw_car(
    surf: pygame.Surface,
    x: float,
    y: float,
    theta: float,
    body_color,
    border_color,
    front_color=None,
    width: int = 2,
) -> None:
    """Draw the car body and a small front-axle marker arrow."""
    corners = car_corners(x, y, theta)
    draw_polygon_world(surf, body_color, corners)
    draw_polygon_world(surf, border_color, corners, width=width)

    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    front_mid = (x + HALF_L * cos_t, y + HALF_L * sin_t)
    tail = (x + (HALF_L - 6) * cos_t, y + (HALF_L - 6) * sin_t)
    fc = front_color if front_color is not None else border_color
    pygame.draw.line(
        surf,
        fc,
        world_to_screen(*tail),
        world_to_screen(*front_mid),
        3,
    )
    arrow_len = 4
    left = (
        front_mid[0] - arrow_len * cos_t + arrow_len * 0.6 * sin_t,
        front_mid[1] - arrow_len * sin_t - arrow_len * 0.6 * cos_t,
    )
    right = (
        front_mid[0] - arrow_len * cos_t - arrow_len * 0.6 * sin_t,
        front_mid[1] - arrow_len * sin_t + arrow_len * 0.6 * cos_t,
    )
    pygame.draw.polygon(
        surf,
        fc,
        [world_to_screen(*front_mid), world_to_screen(*left), world_to_screen(*right)],
    )


def _world_px(x_cm: float, y_cm: float) -> tuple[float, float]:
    """Car canvas pixel coords (float world → screen px, y-up world)."""
    return x_cm * SCALE, CANVAS_PX - y_cm * SCALE


def draw_car_alpha(
    dest: pygame.Surface,
    x_cm: float,
    y_cm: float,
    theta: float,
    body_rgb: tuple[int, int, int],
    border_rgb: tuple[int, int, int],
    front_rgb: tuple[int, int, int],
    body_alpha: int,
    line_alpha: int,
    outline_width: int = 2,
) -> None:
    """Rasterise the same geometry as ``draw_car`` onto an RGBA sprite and ``blit`` it.

    Lets the trajectory show through underneath (path start, end and mid-route).
    """
    corners = car_corners(x_cm, y_cm, theta)
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    front_mid = (x_cm + HALF_L * cos_t, y_cm + HALF_L * sin_t)
    tail = (
        x_cm + (HALF_L - 6) * cos_t,
        y_cm + (HALF_L - 6) * sin_t,
    )
    arrow_len = 4.0
    left = (
        front_mid[0] - arrow_len * cos_t + arrow_len * 0.6 * sin_t,
        front_mid[1] - arrow_len * sin_t - arrow_len * 0.6 * cos_t,
    )
    right = (
        front_mid[0] - arrow_len * cos_t - arrow_len * 0.6 * sin_t,
        front_mid[1] - arrow_len * sin_t + arrow_len * 0.6 * cos_t,
    )

    px_pts: list[tuple[float, float]] = [_world_px(*c) for c in corners]
    line_end = [_world_px(*tail), _world_px(*front_mid)]
    arrow_pts_f = [_world_px(*front_mid), _world_px(*left), _world_px(*right)]
    extras = px_pts + line_end + arrow_pts_f

    pad = float(max(12, outline_width * 5))
    xs = [p[0] for p in extras]
    ys = [p[1] for p in extras]
    ox = math.floor(min(xs) - pad)
    oy = math.floor(min(ys) - pad)
    ow = int(math.ceil(max(xs) - min(xs) + 2 * pad))
    oh = int(math.ceil(max(ys) - min(ys) + 2 * pad))
    if ow < 1 or oh < 1:
        return

    spr = pygame.Surface((ow, oh), pygame.SRCALPHA)

    ba = clamp(body_alpha, 0, 255)
    la = clamp(line_alpha, 0, 255)

    poly = [(int(px - ox), int(py - oy)) for px, py in px_pts]

    pygame.draw.polygon(spr, (*body_rgb, ba), poly)
    pygame.draw.polygon(spr, (*border_rgb, la), poly, outline_width)

    pygame.draw.line(
        spr,
        (*front_rgb, la),
        (int(line_end[0][0] - ox), int(line_end[0][1] - oy)),
        (int(line_end[1][0] - ox), int(line_end[1][1] - oy)),
        3,
    )
    pygame.draw.polygon(
        spr,
        (*front_rgb, la),
        [
            (int(arrow_pts_f[0][0] - ox), int(arrow_pts_f[0][1] - oy)),
            (int(arrow_pts_f[1][0] - ox), int(arrow_pts_f[1][1] - oy)),
            (int(arrow_pts_f[2][0] - ox), int(arrow_pts_f[2][1] - oy)),
        ],
    )

    dest.blit(spr, (ox, oy))


# ---------------------------------------------------------------------------


class Button:
    def __init__(self, rect: pygame.Rect, label: str, key: str):
        self.rect = rect
        self.label = label
        self.key = key
        self.hover = False

    def draw(
        self,
        surf: pygame.Surface,
        font: pygame.font.Font,
        active: bool,
        accent: bool = False,
    ) -> None:
        if active:
            bg = C_BUTTON_ACTIVE
            fg = C_BUTTON_ACTIVE_TEXT
        elif accent:
            bg = C_BUTTON_ACCENT
            fg = C_BUTTON_ACTIVE_TEXT
        elif self.hover:
            bg = C_BUTTON_HOVER
            fg = C_TEXT
        else:
            bg = C_BUTTON
            fg = C_TEXT
        pygame.draw.rect(surf, bg, self.rect, border_radius=6)
        pygame.draw.rect(surf, C_BORDER, self.rect, width=1, border_radius=6)
        txt = font.render(self.label, True, fg)
        surf.blit(
            txt,
            txt.get_rect(center=self.rect.center),
        )


class App:
    def __init__(self) -> None:
        pygame.init()
        pygame.display.set_caption("Hybrid A* Path Planner – Ackermann Car")
        self.screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
        self.canvas = pygame.Surface((CANVAS_PX, CANVAS_PX))
        self.font = pygame.font.SysFont("Arial", 13)
        self.font_b = pygame.font.SysFont("Arial", 13, bold=True)
        self.font_t = pygame.font.SysFont("Arial", 16, bold=True)

        self.start: Optional[tuple[float, float, float]] = None
        self.goal: Optional[tuple[float, float, float]] = None
        self.obstacles: list[tuple[float, float]] = []
        self.path_segments: list[PathSegment] = []
        self.path_poses: list[tuple[float, float, float]] = []
        self.last_result: Optional[PlanResult] = None

        # Sliding car along the planned polyline (arc-length parametrisation).
        self.playback_s = 0.0
        self.playback_playing = False
        self._path_cumulative: list[float] = []
        self._path_total_length = 0.0

        self.mode = "start"
        self.step_size = DEFAULT_STEP

        # Drag state
        self.drag_target: Optional[str] = None      # "start" | "goal"
        self.drag_anchor_world: Optional[tuple[float, float]] = None
        self.drag_current_world: Optional[tuple[float, float]] = None

        # Parking-slot hover (only highlighted when in goal mode).
        self.hover_slot: Optional[tuple[int, float, float, float]] = None

        self.status = "Set start: click & drag to place position and heading."
        self.is_planning = False

        self.buttons: list[Button] = []
        self._build_buttons()

        self.clock = pygame.time.Clock()
        self.running = True

    # ------------- layout ------------------------------------------------
    def _build_buttons(self) -> None:
        x = CANVAS_PX + 18
        w = SIDEBAR_PX - 36
        y = 60
        h = 32

        for key, label in (
            ("start", "Set Start  (S)"),
            ("goal", "Set Goal  (G)"),
            ("obstacle", "Add Obstacle  (O)"),
            ("erase", "Erase Obstacle  (E)"),
        ):
            self.buttons.append(Button(pygame.Rect(x, y, w, h), label, f"mode:{key}"))
            y += h + 8

        # Step size controls
        y += 26  # leaves room for the "Step size" label drawn in render()
        bw_step = 36
        self.buttons.append(Button(pygame.Rect(x, y, bw_step, h), "−", "step:dec"))
        self.buttons.append(Button(pygame.Rect(x + w - bw_step, y, bw_step, h), "+", "step:inc"))
        self._step_label_rect = pygame.Rect(
            x + bw_step + 4, y, w - 2 * bw_step - 8, h
        )
        y += h + 22

        self.buttons.append(Button(pygame.Rect(x, y, w, h + 6), "Plan path  (Enter)", "plan"))
        y += h + 16
        self.buttons.append(Button(pygame.Rect(x, y, w, h), "Clear path  (C)", "clear_path"))
        y += h + 8
        self.buttons.append(Button(pygame.Rect(x, y, w, h), "Clear all  (X)", "clear_all"))

    # ------------- event loop -------------------------------------------
    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            for ev in pygame.event.get():
                self._handle_event(ev)
            self._update_animation(dt)
            self._render()
            pygame.display.flip()
        pygame.quit()

    def _handle_event(self, ev: pygame.event.Event) -> None:
        if ev.type == pygame.QUIT:
            self.running = False
            return

        if ev.type == pygame.MOUSEMOTION:
            mx, my = ev.pos
            for b in self.buttons:
                b.hover = b.rect.collidepoint(mx, my)
            if self.drag_target is not None and 0 <= mx < CANVAS_PX:
                self.drag_current_world = screen_to_world(mx, my)
            # Slot hover highlight (only meaningful while choosing a goal).
            if self.mode == "goal" and 0 <= mx < CANVAS_PX:
                wx, wy = screen_to_world(mx, my)
                self.hover_slot = slot_at(wx, wy)
            else:
                self.hover_slot = None
            return

        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            mx, my = ev.pos
            if mx >= CANVAS_PX:
                self._click_panel(mx, my)
            else:
                self._click_canvas_down(mx, my)
            return

        if ev.type == pygame.MOUSEBUTTONUP and ev.button == 1:
            mx, my = ev.pos
            if self.drag_target is not None:
                self._click_canvas_up(mx, my)
            return

        if ev.type == pygame.KEYDOWN:
            self._handle_key(ev)

    def _handle_key(self, ev: pygame.event.Event) -> None:
        if ev.key == pygame.K_s:
            self._set_mode("start")
        elif ev.key == pygame.K_g:
            self._set_mode("goal")
        elif ev.key == pygame.K_o:
            self._set_mode("obstacle")
        elif ev.key == pygame.K_e:
            self._set_mode("erase")
        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_p):
            self._do_plan()
        elif ev.key == pygame.K_c:
            self.path_segments = []
            self.path_poses = []
            self._sync_playback_geometry()
            self.status = "Path cleared."
        elif ev.key == pygame.K_x:
            self._clear_all()
        elif ev.key == pygame.K_SPACE:
            self.playback_playing = not self.playback_playing
        elif ev.key in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
            self._adjust_step(+STEP_INCR)
        elif ev.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self._adjust_step(-STEP_INCR)
        elif ev.key == pygame.K_ESCAPE:
            self.running = False

    # ------------- canvas interactions ---------------------------------
    def _click_canvas_down(self, mx: int, my: int) -> None:
        wx, wy = screen_to_world(mx, my)
        wx = clamp(wx, 0, AREA_SIZE)
        wy = clamp(wy, 0, AREA_SIZE)
        if self.mode == "start":
            self.drag_target = "start"
            self.drag_anchor_world = (wx, wy)
            self.drag_current_world = (wx, wy)
            self.status = "Drag in the desired heading direction, then release."
        elif self.mode == "goal":
            slot = slot_at(wx, wy)
            if slot is not None:
                self._snap_goal_to_slot(slot)
                return
            self.drag_target = "goal"
            self.drag_anchor_world = (wx, wy)
            self.drag_current_world = (wx, wy)
            self.status = (
                "Drag in the desired heading direction, then release."
                "  (Or click any parking slot to snap.)"
            )
        elif self.mode == "obstacle":
            self._add_obstacle(wx, wy)
        elif self.mode == "erase":
            self._erase_obstacle(wx, wy)

    def _click_canvas_up(self, mx: int, my: int) -> None:
        if self.drag_anchor_world is None or self.drag_target is None:
            self.drag_target = None
            return
        wx, wy = screen_to_world(mx, my)
        ax, ay = self.drag_anchor_world
        dx = wx - ax
        dy = wy - ay
        # If the user did not drag, keep an existing heading or default to 0.
        if math.hypot(dx, dy) < 1.0:
            existing = self.start if self.drag_target == "start" else self.goal
            theta = existing[2] if existing is not None else 0.0
        else:
            theta = math.atan2(dy, dx)

        pose = (clamp(ax, 0, AREA_SIZE), clamp(ay, 0, AREA_SIZE), theta)

        valid = state_is_valid(pose[0], pose[1], pose[2], self.obstacles)
        if not valid:
            self.status = (
                f"{self.drag_target.title()} pose collides with the boundary or "
                "an obstacle. Try a different spot."
            )
        else:
            if self.drag_target == "start":
                self.start = pose
                self.status = (
                    f"Start set to ({pose[0]:.1f}, {pose[1]:.1f}) cm, "
                    f"{math.degrees(pose[2]):.1f}°."
                )
            else:
                self.goal = pose
                self.status = (
                    f"Goal set to ({pose[0]:.1f}, {pose[1]:.1f}) cm, "
                    f"{math.degrees(pose[2]):.1f}°."
                )
            # Invalidate the previous path
            self.path_segments = []
            self.path_poses = []
            self._sync_playback_geometry()
        self.drag_target = None
        self.drag_anchor_world = None
        self.drag_current_world = None

    def _add_obstacle(self, wx: float, wy: float) -> None:
        # Snap to integer cm to keep things tidy.
        wx = round(wx)
        wy = round(wy)
        wx = clamp(wx, OBSTACLE_HALF, AREA_SIZE - OBSTACLE_HALF)
        wy = clamp(wy, OBSTACLE_HALF, AREA_SIZE - OBSTACLE_HALF)
        self.obstacles.append((wx, wy))
        self.path_segments = []
        self.path_poses = []
        self._sync_playback_geometry()
        self.status = f"Obstacle added at ({wx:.0f}, {wy:.0f}) cm."

    def _erase_obstacle(self, wx: float, wy: float) -> None:
        idx = obstacle_at(wx, wy, self.obstacles)
        if idx >= 0:
            self.obstacles.pop(idx)
            self.path_segments = []
            self.path_poses = []
            self._sync_playback_geometry()
            self.status = "Obstacle removed."
        else:
            self.status = "Click on an obstacle to erase it."

    # ------------- panel interactions ---------------------------------
    def _click_panel(self, mx: int, my: int) -> None:
        for b in self.buttons:
            if b.rect.collidepoint(mx, my):
                self._handle_button(b.key)
                return

    def _handle_button(self, key: str) -> None:
        if key.startswith("mode:"):
            self._set_mode(key.split(":", 1)[1])
        elif key == "step:inc":
            self._adjust_step(+STEP_INCR)
        elif key == "step:dec":
            self._adjust_step(-STEP_INCR)
        elif key == "plan":
            self._do_plan()
        elif key == "clear_path":
            self.path_segments = []
            self.path_poses = []
            self._sync_playback_geometry()
            self.status = "Path cleared."
        elif key == "clear_all":
            self._clear_all()

    def _set_mode(self, mode: str) -> None:
        self.mode = mode
        self.drag_target = None
        if mode != "goal":
            self.hover_slot = None
        msg = {
            "start": "Set start: click & drag to place position and heading.",
            "goal": (
                "Set goal: click & drag for a custom pose, or click a "
                "parking slot to snap."
            ),
            "obstacle": "Click anywhere on the canvas to drop a 5×5 cm obstacle.",
            "erase": "Click on an obstacle to remove it.",
        }
        self.status = msg.get(mode, "")

    def _snap_goal_to_slot(
        self, slot: tuple[int, float, float, float]
    ) -> None:
        sid, cx, cy, yaw = slot
        if not state_is_valid(cx, cy, yaw, self.obstacles):
            self.status = (
                f"Slot {sid} is blocked by an obstacle right now."
            )
            return
        self.goal = (cx, cy, yaw)
        self.path_segments = []
        self.path_poses = []
        self._sync_playback_geometry()
        self.status = (
            f"Goal set to parking slot {sid} "
            f"({cx:.1f}, {cy:.1f}) cm, {math.degrees(yaw):.0f}°."
        )

    def _adjust_step(self, delta: float) -> None:
        new = round((self.step_size + delta) * 2) / 2
        self.step_size = clamp(new, STEP_MIN, STEP_MAX)
        self.status = f"Step size = {self.step_size:.1f} cm."

    def _clear_all(self) -> None:
        self.start = None
        self.goal = None
        self.obstacles = []
        self.path_segments = []
        self.path_poses = []
        self.last_result = None
        self._sync_playback_geometry()
        self.status = "Cleared. Set a start pose to begin."

    # ------------- planning --------------------------------------------
    def _do_plan(self) -> None:
        if self.start is None:
            self.status = "Set a start pose first."
            return
        if self.goal is None:
            self.status = "Set a goal pose first."
            return

        self.is_planning = True
        self.status = "Planning..."
        self._render()
        pygame.display.flip()

        result = plan(self.start, self.goal, self.obstacles, self.step_size)
        self.last_result = result
        self.path_segments = result.segments
        self.path_poses = result.poses
        self._sync_playback_geometry(
            restart_from_start=result.success and len(result.poses) > 1
        )
        self.is_planning = False
        if result.success:
            length = sum(
                math.hypot(b[0] - a[0], b[1] - a[1])
                for a, b in zip(result.poses, result.poses[1:])
            )
            relaxed_tag = "  [relaxed]" if getattr(result, "relaxed", False) else ""
            self.status = (
                f"{result.message}{relaxed_tag}  length≈{length:.1f} cm, "
                f"iter={result.iterations}, time={result.elapsed*1000:.0f} ms."
            )
        else:
            self.status = f"{result.message}  iter={result.iterations}, time={result.elapsed*1000:.0f} ms."

    # ------------- playback along path -------------------------------------
    def _sync_playback_geometry(self, *, restart_from_start: bool = False) -> None:
        """Rebuild cumulative arc lengths from ``path_poses``."""
        poses = self.path_poses
        if len(poses) < 2:
            self._path_cumulative = []
            self._path_total_length = 0.0
            self.playback_s = 0.0
            self.playback_playing = False
            return
        cum: list[float] = [0.0]
        total = 0.0
        for i in range(len(poses) - 1):
            dx = poses[i + 1][0] - poses[i][0]
            dy = poses[i + 1][1] - poses[i][1]
            total += math.hypot(dx, dy)
            cum.append(total)
        self._path_cumulative = cum
        self._path_total_length = total

        if restart_from_start:
            self.playback_s = 0.0
            self.playback_playing = total > 1e-6
        elif self.playback_s > self._path_total_length:
            self.playback_s %= max(self._path_total_length, 1e-9)

    def _pose_on_polyline_at(self, s_dist: float) -> tuple[float, float, float]:
        """Interpolated pose at arc length ``s_dist`` along ``path_poses``."""
        poses = self.path_poses
        cum = self._path_cumulative
        tl = self._path_total_length
        if len(poses) == 1:
            return poses[0]
        if tl <= 1e-9:
            return poses[0]

        sd = math.fmod(s_dist, tl)
        if sd < 0:
            sd += tl
        idx = bisect.bisect_right(cum, sd) - 1
        idx = max(0, min(idx, len(poses) - 2))
        c0, c1 = cum[idx], cum[idx + 1]
        ds = max(c1 - c0, 1e-9)
        u = max(0.0, min(1.0, (sd - c0) / ds))
        x0, y0, h0 = poses[idx]
        x1, y1, h1 = poses[idx + 1]
        dh = math.atan2(math.sin(h1 - h0), math.cos(h1 - h0))
        return (
            x0 + u * (x1 - x0),
            y0 + u * (y1 - y0),
            h0 + u * dh,
        )

    def _update_animation(self, dt_raw: float) -> None:
        if not self.path_poses:
            return
        if len(self.path_poses) < 2 or self._path_total_length <= 1e-9:
            return
        if not self.playback_playing:
            return
        dt = max(1e-4, min(dt_raw, 1.0 / 15.0))
        self.playback_s += PLAYBACK_SPEED_CM_S * dt
        self.playback_s = math.fmod(self.playback_s, self._path_total_length)

    # ------------- rendering -------------------------------------------
    def _render(self) -> None:
        self.screen.fill(C_BG)
        self._render_canvas()
        self.screen.blit(self.canvas, (0, 0))
        self._render_panel()

    def _render_canvas(self) -> None:
        self.canvas.fill((255, 255, 255))

        # Grid every 10 cm; thicker lines every 50 cm.
        for cm in range(0, int(AREA_SIZE) + 1, 10):
            color = C_AXIS if cm % 50 == 0 else C_GRID
            wd = 2 if cm % 50 == 0 else 1
            sx = int(cm * SCALE)
            pygame.draw.line(self.canvas, color, (sx, 0), (sx, CANVAS_PX), wd)
            sy = int(CANVAS_PX - cm * SCALE)
            pygame.draw.line(self.canvas, color, (0, sy), (CANVAS_PX, sy), wd)

        # Workspace border
        pygame.draw.rect(
            self.canvas, C_BORDER, pygame.Rect(0, 0, CANVAS_PX, CANVAS_PX), 2
        )

        # Parking slots (drawn under obstacles & path so they form a backdrop).
        for slot in PARKING_SLOTS:
            sid, cx, cy, yaw = slot
            corners = slot_corners(cx, cy, yaw)
            is_hover = self.hover_slot is not None and self.hover_slot[0] == sid
            fill = C_SLOT_HOVER if is_hover else C_SLOT_FILL
            outline = C_SLOT_HOVER_OUTLINE if is_hover else C_SLOT_OUTLINE
            draw_polygon_world(self.canvas, fill, corners)
            draw_polygon_world(self.canvas, outline, corners, width=2)

            # Heading indicator: short arrow from slot centre toward yaw.
            ahead_len = SLOT_LENGTH * 0.32
            cosy = math.cos(yaw)
            siny = math.sin(yaw)
            tip = (cx + ahead_len * cosy, cy + ahead_len * siny)
            tail = (cx - ahead_len * 0.35 * cosy, cy - ahead_len * 0.35 * siny)
            pygame.draw.line(
                self.canvas, outline,
                world_to_screen(*tail), world_to_screen(*tip), 2,
            )
            head_w = 3.0
            left = (
                tip[0] - 4.0 * cosy + head_w * siny,
                tip[1] - 4.0 * siny - head_w * cosy,
            )
            right = (
                tip[0] - 4.0 * cosy - head_w * siny,
                tip[1] - 4.0 * siny + head_w * cosy,
            )
            pygame.draw.polygon(
                self.canvas, outline,
                [world_to_screen(*tip), world_to_screen(*left), world_to_screen(*right)],
            )

            # ID label – placed slightly behind the slot centre so it does
            # not overlap the heading arrow.
            label = self.font_b.render(str(sid), True, C_SLOT_TEXT)
            label_pos_world = (
                cx - ahead_len * 0.55 * cosy,
                cy - ahead_len * 0.55 * siny,
            )
            lbl_screen = world_to_screen(*label_pos_world)
            self.canvas.blit(label, label.get_rect(center=lbl_screen))

        # Obstacles
        for ox, oy in self.obstacles:
            r = pygame.Rect(0, 0, int(OBSTACLE_SIZE * SCALE), int(OBSTACLE_SIZE * SCALE))
            tlx, tly = world_to_screen(ox - OBSTACLE_HALF, oy + OBSTACLE_HALF)
            r.topleft = (tlx, tly)
            pygame.draw.rect(self.canvas, C_OBSTACLE, r)
            pygame.draw.rect(self.canvas, C_OBSTACLE_BORDER, r, 1)

        # Path
        for seg in self.path_segments:
            color = C_PATH_FWD if seg.direction >= 0 else C_PATH_REV
            pts = [world_to_screen(p[0], p[1]) for p in seg.poses]
            if len(pts) >= 2:
                pygame.draw.lines(self.canvas, color, False, pts, 4)

        # Drag preview
        if (
            self.drag_target is not None
            and self.drag_anchor_world is not None
            and self.drag_current_world is not None
        ):
            ax, ay = self.drag_anchor_world
            cx, cy = self.drag_current_world
            theta = math.atan2(cy - ay, cx - ax) if math.hypot(cx - ax, cy - ay) > 0.5 else 0.0
            valid = state_is_valid(ax, ay, theta, self.obstacles)
            preview_color = (200, 220, 255) if valid else (255, 220, 220)
            border_color = C_INVALID if not valid else (
                C_START if self.drag_target == "start" else C_GOAL
            )
            draw_car(self.canvas, ax, ay, theta, preview_color, border_color, width=2)
            pygame.draw.line(
                self.canvas,
                C_DRAG,
                world_to_screen(ax, ay),
                world_to_screen(cx, cy),
                2,
            )

        # Start — translucent when the path overlaps this pose layer.
        if self.start is not None:
            x, y, t = self.start
            if self._path_total_length > 1e-9 and self.path_segments:
                draw_car_alpha(
                    self.canvas,
                    x,
                    y,
                    t,
                    (210, 225, 250),
                    C_START,
                    C_START,
                    ALPHA_POSE_BODY_OVER_PATH,
                    ALPHA_POSE_LINES_OVER_PATH,
                    outline_width=2,
                )
            else:
                draw_car(self.canvas, x, y, t, (210, 225, 250), C_START, front_color=C_START, width=2)

        # Goal
        if self.goal is not None:
            x, y, t = self.goal
            if self._path_total_length > 1e-9 and self.path_segments:
                draw_car_alpha(
                    self.canvas,
                    x,
                    y,
                    t,
                    (250, 215, 220),
                    C_GOAL,
                    C_GOAL,
                    ALPHA_POSE_BODY_OVER_PATH,
                    ALPHA_POSE_LINES_OVER_PATH,
                    outline_width=2,
                )
            else:
                draw_car(self.canvas, x, y, t, (250, 215, 220), C_GOAL, front_color=C_GOAL, width=2)

        # One car sliding along the planned polyline (drawn above start / goal).
        if self._path_total_length > 1e-9 and len(self.path_poses) >= 2:
            ax, ay, ath = self._pose_on_polyline_at(self.playback_s)
            draw_car_alpha(
                self.canvas,
                ax,
                ay,
                ath,
                C_ANIM_CAR,
                C_ANIM_CAR_BORDER,
                C_ANIM_CAR_BORDER,
                ALPHA_SLIDE_BODY,
                ALPHA_SLIDE_LINES,
                outline_width=2,
            )

    def _render_panel(self) -> None:
        panel_rect = pygame.Rect(CANVAS_PX, 0, SIDEBAR_PX, WINDOW_H)
        pygame.draw.rect(self.screen, C_PANEL, panel_rect)
        pygame.draw.line(
            self.screen, C_BORDER,
            (CANVAS_PX, 0), (CANVAS_PX, WINDOW_H), 1,
        )

        title = self.font_t.render("Hybrid A*", True, C_TEXT)
        self.screen.blit(title, (CANVAS_PX + 18, 18))
        sub = self.font.render("Ackermann path planner", True, C_TEXT_DIM)
        self.screen.blit(sub, (CANVAS_PX + 18, 38))

        active_mode_key = f"mode:{self.mode}"
        for b in self.buttons:
            accent = b.key == "plan"
            active = b.key == active_mode_key
            b.draw(self.screen, self.font_b, active=active, accent=accent and not active)

        # Step size header above the +/- buttons
        step_buttons = [b for b in self.buttons if b.key.startswith("step:")]
        if step_buttons:
            top = step_buttons[0].rect.top
            label = self.font_b.render("Step size", True, C_TEXT)
            self.screen.blit(label, (CANVAS_PX + 18, top - 22))
            value_txt = self.font_b.render(
                f"{self.step_size:.1f} cm", True, C_TEXT
            )
            self.screen.blit(
                value_txt,
                value_txt.get_rect(center=self._step_label_rect.center),
            )

        # Info block sits below the last button, with a margin.
        last_button_bottom = max(b.rect.bottom for b in self.buttons)
        info_y = last_button_bottom + 24
        info_lines = [
            ("Path", "green = fwd, red = rev"),
            ("Animation", "Space = pause/play"),
            ("Goal", "click slot or drag"),
            ("Vehicle", ""),
            ("  body", f"{CAR_LENGTH:.0f} × {CAR_WIDTH:.0f} cm"),
            ("  wheelbase", f"{WHEELBASE:.0f} cm"),
            ("  max steer", "±25° (plan ±22.5°)"),
            ("Workspace", f"{int(AREA_SIZE)} × {int(AREA_SIZE)} cm"),
            ("Obstacle size", f"{OBSTACLE_SIZE:.0f} × {OBSTACLE_SIZE:.0f} cm"),
            ("Obstacles", f"{len(self.obstacles)}"),
            ("Parking slots", f"{len(PARKING_SLOTS)}"),
            ("Min seg / change", "20 cm"),
        ]
        y = info_y
        for k, v in info_lines:
            color = C_TEXT if k.strip() and not k.startswith("  ") else C_TEXT_DIM
            label = self.font.render(k, True, color)
            self.screen.blit(label, (CANVAS_PX + 18, y))
            if v:
                vsurf = self.font.render(v, True, C_TEXT)
                self.screen.blit(
                    vsurf,
                    (CANVAS_PX + SIDEBAR_PX - 18 - vsurf.get_width(), y),
                )
            y += 18

        # Status bar at the very bottom of the screen, full window width
        status_h = 26
        status_rect = pygame.Rect(0, WINDOW_H - status_h, CANVAS_PX, status_h)
        pygame.draw.rect(self.screen, (35, 40, 55), status_rect)
        prefix = "[planning] " if self.is_planning else ""
        msg = self.font_b.render(prefix + self.status, True, (240, 245, 255))
        self.screen.blit(msg, (8, WINDOW_H - status_h + 6))


def main() -> None:
    App().run()


if __name__ == "__main__":
    main()
