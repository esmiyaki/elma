"""Boundary and obstacle collision checks.

The car footprint is an oriented rectangle, the obstacles are 5 × 5 cm
axis-aligned squares. We use the Separating Axis Theorem (SAT) to test
whether two convex polygons overlap. SAT is exact for arbitrary convex
shapes and only needs the polygon edge normals.

For speed during planning we also do a quick circle pre-filter: if the
distance between the rectangles' centres is greater than the sum of
their bounding radii they cannot collide and SAT is skipped.
"""

from __future__ import annotations

import math
from typing import Iterable, Sequence

from vehicle import CAR_LENGTH, CAR_WIDTH, HALF_L, HALF_W


AREA_SIZE = 200.0          # cm – workspace edge length (square)
OBSTACLE_SIZE = 5.0        # cm – obstacle edge length
OBSTACLE_HALF = OBSTACLE_SIZE / 2.0

# Default safety buffer (cm) added to *every* side of the car footprint when
# checking collisions. This keeps a small clearance between the planned
# trajectory and obstacles / walls, accounting for actuator slop, tyre slip,
# imperfect localisation, and discretisation error in the planner.
COLLISION_MARGIN = 3.0

_OBSTACLE_RADIUS = OBSTACLE_HALF * math.sqrt(2.0)


def _inflated_corners(
    x: float, y: float, theta: float, margin: float
) -> list[tuple[float, float]]:
    """Footprint corners with the rectangle uniformly grown by ``margin``."""
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    half_l = HALF_L + margin
    half_w = HALF_W + margin
    out: list[tuple[float, float]] = []
    for dl, dw in (
        ( half_l,  half_w),
        ( half_l, -half_w),
        (-half_l, -half_w),
        (-half_l,  half_w),
    ):
        out.append((
            x + dl * cos_t - dw * sin_t,
            y + dl * sin_t + dw * cos_t,
        ))
    return out


def _car_radius(margin: float) -> float:
    return 0.5 * math.hypot(CAR_LENGTH + 2.0 * margin, CAR_WIDTH + 2.0 * margin)


def in_bounds(
    x: float, y: float, theta: float, margin: float = COLLISION_MARGIN,
) -> bool:
    """Return True if the (inflated) car footprint is inside the workspace."""
    for cx, cy in _inflated_corners(x, y, theta, margin):
        if cx < 0.0 or cx > AREA_SIZE or cy < 0.0 or cy > AREA_SIZE:
            return False
    return True


def _project(poly: Sequence[tuple[float, float]], ax: float, ay: float) -> tuple[float, float]:
    lo = hi = poly[0][0] * ax + poly[0][1] * ay
    for px, py in poly[1:]:
        v = px * ax + py * ay
        if v < lo:
            lo = v
        elif v > hi:
            hi = v
    return lo, hi


def _polygons_overlap(
    poly_a: Sequence[tuple[float, float]],
    poly_b: Sequence[tuple[float, float]],
) -> bool:
    """SAT check between two convex polygons (CCW or CW both ok)."""
    for poly in (poly_a, poly_b):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            length = math.hypot(ax, ay)
            if length == 0.0:
                continue
            ax /= length
            ay /= length
            a_lo, a_hi = _project(poly_a, ax, ay)
            b_lo, b_hi = _project(poly_b, ax, ay)
            if a_hi < b_lo or b_hi < a_lo:
                return False
    return True


def _obstacle_corners(ox: float, oy: float) -> list[tuple[float, float]]:
    return [
        (ox - OBSTACLE_HALF, oy - OBSTACLE_HALF),
        (ox + OBSTACLE_HALF, oy - OBSTACLE_HALF),
        (ox + OBSTACLE_HALF, oy + OBSTACLE_HALF),
        (ox - OBSTACLE_HALF, oy + OBSTACLE_HALF),
    ]


def car_collides(
    x: float,
    y: float,
    theta: float,
    obstacles: Iterable[tuple[float, float]],
    margin: float = COLLISION_MARGIN,
) -> bool:
    """Return True if the inflated car footprint overlaps any obstacle."""
    car = _inflated_corners(x, y, theta, margin)
    broad_radius = _car_radius(margin) + _OBSTACLE_RADIUS
    broad_radius_sq = broad_radius * broad_radius
    for ox, oy in obstacles:
        dx = ox - x
        dy = oy - y
        if dx * dx + dy * dy > broad_radius_sq:
            continue
        if _polygons_overlap(car, _obstacle_corners(ox, oy)):
            return True
    return False


def state_is_valid(
    x: float,
    y: float,
    theta: float,
    obstacles: Iterable[tuple[float, float]],
    margin: float = COLLISION_MARGIN,
) -> bool:
    """Combined boundary + obstacle check (with safety margin)."""
    if not in_bounds(x, y, theta, margin=margin):
        return False
    if car_collides(x, y, theta, obstacles, margin=margin):
        return False
    return True


def obstacle_at(
    sx: float, sy: float, obstacles: Iterable[tuple[float, float]]
) -> int:
    """Index of the obstacle containing point (sx, sy), or -1."""
    for idx, (ox, oy) in enumerate(obstacles):
        if abs(sx - ox) <= OBSTACLE_HALF and abs(sy - oy) <= OBSTACLE_HALF:
            return idx
    return -1
