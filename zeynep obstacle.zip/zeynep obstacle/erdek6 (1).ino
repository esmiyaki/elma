#include <Servo.h>

const int SERVO_FRONT_PIN = 11;
const int TRIG_FRONT_PIN = 8;
const int ECHO_FRONT_PIN = 9;

const int SERVO_BACK_PIN = 10;
const int TRIG_BACK_PIN = 12;
const int ECHO_BACK_PIN = 13;

Servo radarServoFront;
Servo radarServoBack;

// Tarama Ayarları
const int NARROW_START = 60;
const int NARROW_END = 120;
const int STEP = 5;

// --- YENİ: KALİBRASYON VE FİLTRE AYARLARI ---
const int SERVO_OFFSET = 0; // Beyaz pin (horn) 90 derecede tam düz bakmıyorsa burayı (örn: 2 veya -3) değiştir.
const long TIMEOUT_US = 8500; // 100 cm maksimum algılama sınırı (~103 cm'ye denk gelir. 100cm gidiş-dönüş = 5830 us).

void setup() {
  pinMode(TRIG_FRONT_PIN, OUTPUT);
  pinMode(ECHO_FRONT_PIN, INPUT);
  pinMode(TRIG_BACK_PIN, OUTPUT);
  pinMode(ECHO_BACK_PIN, INPUT);
  
  radarServoFront.attach(SERVO_FRONT_PIN);
  radarServoBack.attach(SERVO_BACK_PIN);
  Serial.begin(115200);

  // 1. AŞAMA: KALİBRASYON (TAM TARAMA)
  for (int angle = 10; angle <= 170; angle += 2) {
    scanAndSend(angle);
  }
  
  // 2. AŞAMA: YANSIMA SÖNÜMLEME
  // 3 saniye bekleme (Yansımalar bitsin ve Python veriyi işlesin)
  delay(3000);
}

void loop() {
  // 3. AŞAMA: HAREKETLİ DAR AÇI TARAMASI
  for (int angle = NARROW_START; angle <= NARROW_END; angle += STEP) {
    scanAndSend(angle);
  }
  for (int angle = NARROW_END; angle >= NARROW_START; angle -= STEP) {
    scanAndSend(angle);
  }
}

void scanAndSend(int angle) {
  // --- YENİ: Yazılımsal Hizalama (Trim) ---
  radarServoFront.write(angle + SERVO_OFFSET);
  radarServoBack.write(angle + SERVO_OFFSET);
  
  // --- YENİ: Servo sarsıntısı ve akım gürültüsü sönümlenme süresi (150ms -> 200ms) ---
  delay(200); 
  
  int distF = calculateDistance(TRIG_FRONT_PIN, ECHO_FRONT_PIN);
  
  // --- YENİ: Akustik Yankı (Crosstalk) Sönümlenme Süresi (40ms -> 80ms) ---
  delay(60); 
  
  int distB = calculateDistance(TRIG_BACK_PIN, ECHO_BACK_PIN);
  
  Serial.print(angle);
  Serial.print(",");
  Serial.print(distF);
  Serial.print(",");
  Serial.println(distB);
}

int calculateDistance(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // --- YENİ: 100 cm Donanımsal Sınır (Kör Nokta Optimizasyonu) ---
  // Ses dalgası 6000 mikrosaniye içinde dönmezse nesne 100 cm'den uzaktadır.
  long duration = pulseIn(echoPin, HIGH, TIMEOUT_US);
  
  // Timeout olduysa (nesne yoksa veya 100cm dışındaysa), Python'un boş alan sayması için 200 gönder.
  if (duration == 0) {
    return 200; 
  }
  
  return (duration * 0.0343 / 2);
}