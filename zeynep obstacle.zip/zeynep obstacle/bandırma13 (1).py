import serial
import time
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.ticker as ticker 
from shapely.geometry import box, Polygon
from shapely.affinity import rotate, translate

# --- KODSON.PY'DEN ALINAN HARİTA VE ARAÇ VERİLERİ ---
MAP_SIZE = 200
SLOT_W, SLOT_D = 25.0, 40.0  
CAR_L, CAR_W = 25.0, 15.0

def create_slots():
    slots, counter = [], 1
    total_w_top = 3 * SLOT_W; start_x_top = (MAP_SIZE - total_w_top) / 2 + (SLOT_W / 2)
    for i in range(3):
        slots.append({'cx': start_x_top + (i * SLOT_W), 'cy': MAP_SIZE - (SLOT_D / 2), 'yaw': -np.pi/2, 'id': counter}); counter += 1
    total_h_side = 6 * SLOT_W; start_y_side = (MAP_SIZE - total_h_side) / 2 + (SLOT_W / 2)
    for i in range(6):
        slots.append({'cx': SLOT_D / 2, 'cy': start_y_side + (i * SLOT_W), 'yaw': 0, 'id': counter}); counter += 1
    for i in range(6):
        slots.append({'cx': MAP_SIZE - (SLOT_D / 2), 'cy': start_y_side + (i * SLOT_W), 'yaw': np.pi, 'id': counter}); counter += 1
    return slots

def get_car_polygon(x, y, yaw, padding=0.0):
    l, w = CAR_L + (2 * padding), CAR_W + (2 * padding)
    outline = np.array([[-l/2, -w/2], [l/2, -w/2], [l/2, w/2], [-l/2, w/2]])
    c, s = np.cos(yaw), np.sin(yaw)
    rot = np.array([[c, -s], [s, c]])
    rotated = outline.dot(rot.T)
    rotated[:, 0] += x
    rotated[:, 1] += y
    return Polygon(rotated)

def extract_obstacle_centroids(distances, angles_deg, max_range=200, jump_tolerance=15.0):
    valid_indices = np.where(distances < max_range)[0]
    if len(valid_indices) == 0:
        return np.array([]), np.array([])
        
    clusters = []
    current_cluster = [valid_indices[0]]
    
    for i in range(1, len(valid_indices)):
        prev_idx = valid_indices[i-1]
        curr_idx = valid_indices[i]
        
        if (curr_idx - prev_idx <= 6) and abs(distances[curr_idx] - distances[prev_idx]) <= jump_tolerance:
            current_cluster.append(curr_idx)
        else:
            clusters.append(current_cluster)
            current_cluster = [curr_idx]
    clusters.append(current_cluster)
    
    centroid_angles = []
    centroid_distances = []
    
    for cluster in clusters:
        true_angle = np.mean(angles_deg[cluster]) 
        true_dist = np.min(distances[cluster])    
        centroid_angles.append(true_angle)
        centroid_distances.append(true_dist)
        
    return np.array(centroid_angles), np.array(centroid_distances)

class SerialSensorProvider:
    def __init__(self, port='COM3', baudrate=115200):
        self.ser = None
        try:
            self.ser = serial.Serial(port, baudrate, timeout=0.01)
            time.sleep(2) 
            print(f"[SYSTEM] {port} successfully connected, wait for data...")
        except Exception as e:
            print(f"[WARNING] {port} check the cable and the port.")
            print(f"Error: {e}")

    def get_data(self):
        if self.ser and self.ser.in_waiting > 0:
            try:
                line = self.ser.readline().decode('utf-8').strip()
                if line.count(',') == 2:
                    angle_str, dist_f_str, dist_b_str = line.split(',')
                    return int(angle_str), int(dist_f_str), int(dist_b_str)
            except:
                pass 
        return None, None, None

class RadarApp:
    def __init__(self, data_provider):
        self.provider = data_provider
        self.max_dist = 200.0 
        self.angles_deg = np.arange(0, 181)
        
        self.distances_f = np.full(181, self.max_dist) 
        self.distances_b = np.full(181, self.max_dist) 
        
        self.locked_f = np.full(181, self.max_dist)
        self.locked_b = np.full(181, self.max_dist)

        self.history_f = {a: [200, 200] for a in range(181)}
        self.history_b = {a: [200, 200] for a in range(181)}
        
        self.last_centroids_f = (np.array([]), np.array([]))
        self.last_centroids_b = (np.array([]), np.array([]))
        
        self.is_calibrated = False
        self.calibration_count = 0
        self.tolerance = 15.0 
        self.stability_threshold = 20.0 
        
        self.car_x = 0 
        self.car_y = 0 
        self.car_yaw = np.pi / 2 
        
        self.setup_plot()

    def setup_plot(self):
        self.fig = plt.figure(figsize=(16, 8))
        self.fig.canvas.manager.set_window_title('Dual View: Polar Radar & XY Plane')

        self.ax_polar = self.fig.add_subplot(121, projection='polar')
        self.ax_polar.set_ylim(0, 150) 
        self.ax_polar.set_theta_zero_location('N')
        self.ax_polar.set_theta_direction(-1) 
        self.ax_polar.set_title("Polar Radar View", va='bottom', fontweight='bold')
        self.ax_polar.set_facecolor('#001100') 
        
        self.scatter_f_polar = self.ax_polar.scatter([], [], c='lime', s=30, alpha=0.8, label="Front Radar")
        self.scatter_b_polar = self.ax_polar.scatter([], [], c='cyan', s=30, alpha=0.8, label="Back Radar")
        self.ax_polar.legend(loc='upper right')

        self.ax_xy = self.fig.add_subplot(122)
        self.ax_xy.set_xlim(-100, 100) 
        self.ax_xy.set_ylim(-100, 100) 
        self.ax_xy.set_aspect('equal')
        self.ax_xy.set_title("XY Plane (Occupancy Grid)", fontweight='bold')
        
        self.ax_xy.spines['left'].set_position('zero')
        self.ax_xy.spines['bottom'].set_position('zero')
        self.ax_xy.spines['right'].set_color('none')
        self.ax_xy.spines['top'].set_color('none')

        self.ax_xy.xaxis.set_major_locator(ticker.MultipleLocator(50))
        self.ax_xy.xaxis.set_minor_locator(ticker.MultipleLocator(10))
        self.ax_xy.yaxis.set_major_locator(ticker.MultipleLocator(50))
        self.ax_xy.yaxis.set_minor_locator(ticker.MultipleLocator(10))
        self.ax_xy.grid(which='major', color='#888888', linestyle='-', alpha=0.5)
        self.ax_xy.grid(which='minor', color='#AAAAAA', linestyle=':', alpha=0.3)
        
        for r in [50, 100, 150]:
            circle = plt.Circle((self.car_x, self.car_y), r, color='blue', fill=False, linestyle='--', alpha=0.4, zorder=2)
            self.ax_xy.add_patch(circle)
            self.ax_xy.text(self.car_x + r, self.car_y + 2, f"{r}cm", color='blue', fontsize=8, alpha=0.8, zorder=3)

        for angle in range(0, 360, 30):
            rad = np.deg2rad(angle)
            x_end = self.car_x + 150 * np.cos(rad)
            y_end = self.car_y + 150 * np.sin(rad)
            self.ax_xy.plot([self.car_x, x_end], [self.car_y, y_end], color='red', linestyle=':', alpha=0.4, zorder=2)
            self.ax_xy.text(x_end, y_end, f"{angle}°", color='red', fontsize=8, alpha=0.8, ha='center', va='center', zorder=3)
        
        slots = create_slots()
        for s in slots:
            cx_shifted = s['cx'] - (MAP_SIZE / 2)
            cy_shifted = s['cy'] - (MAP_SIZE / 2)
            p = translate(rotate(box(-SLOT_D/2, -SLOT_W/2, SLOT_D/2, SLOT_W/2), s['yaw'], use_radians=True), cx_shifted, cy_shifted)
            self.ax_xy.plot(*p.exterior.xy, color='#333333', linestyle='--', zorder=1)
            
        car_poly = get_car_polygon(self.car_x, self.car_y, self.car_yaw)
        self.ax_xy.fill(*car_poly.exterior.xy, color='#00ced1', alpha=0.7, edgecolor='black', zorder=4)
        
        self.scatter_f_inflated = self.ax_xy.scatter([], [], c='lime', s=1500, alpha=0.2, zorder=3)
        self.scatter_b_inflated = self.ax_xy.scatter([], [], c='cyan', s=1500, alpha=0.2, zorder=3)

        self.scatter_f_xy = self.ax_xy.scatter([], [], c='lime', s=30, alpha=0.9, zorder=5)
        self.scatter_b_xy = self.ax_xy.scatter([], [], c='cyan', s=30, alpha=0.9, zorder=5)

    def _update_frame(self, frame):
        while True:
            angle, dist_f, dist_b = self.provider.get_data()
            if angle is None:
                break 
            
            if 0 <= angle <= 180:
                if not self.is_calibrated:
                    self.locked_f[angle] = dist_f
                    self.locked_b[angle] = dist_b
                    self.distances_f[angle] = dist_f
                    self.distances_b[angle] = dist_b
                    self.calibration_count += 1
                    
                    if self.calibration_count >= 80:
                        self.is_calibrated = True
                        print("\n==================================================")
                        print("[SYSTEM] Kalibrasyon Tamamlandı.")
                        print("==================================================\n")
                else:
                    self.history_f[angle].pop(0)
                    self.history_f[angle].append(dist_f)
                    
                    self.history_b[angle].pop(0)
                    self.history_b[angle].append(dist_b)

                    prev_f, curr_f = self.history_f[angle]
                    if curr_f == 200 and prev_f == 200:
                        if self.locked_f[angle] != 200:
                            self.locked_f[angle] = 200
                    elif abs(curr_f - prev_f) <= self.stability_threshold:
                        if abs(curr_f - self.locked_f[angle]) > self.tolerance:
                            self.locked_f[angle] = curr_f 
                    
                    prev_b, curr_b = self.history_b[angle]
                    if curr_b == 200 and prev_b == 200:
                        if self.locked_b[angle] != 200:
                            self.locked_b[angle] = 200
                    elif abs(curr_b - prev_b) <= self.stability_threshold:
                        if abs(curr_b - self.locked_b[angle]) > self.tolerance:
                            self.locked_b[angle] = curr_b

                    self.distances_f[angle] = self.locked_f[angle]
                    self.distances_b[angle] = self.locked_b[angle]

                    if angle == 60 or angle == 120:
                        self.last_centroids_f = extract_obstacle_centroids(self.distances_f, self.angles_deg)
                        self.last_centroids_b = extract_obstacle_centroids(self.distances_b, self.angles_deg)

        # --- YENİ ÇİZİM MANTIĞI: OFFSET SİLİNDİ, DOĞRUDAN AÇI KULLANIMI ---
        angles_f, dists_f = self.last_centroids_f
        if len(angles_f) > 0:
            # Ön Sensör: 90 derece 'N' (Kuzey/Yukarı) yönüdür.
            polar_angles_f_rad = np.deg2rad(90 - angles_f)
            xy_angles_f_rad = np.deg2rad(angles_f)
            
            self.scatter_f_polar.set_offsets(np.c_[polar_angles_f_rad, dists_f])
            
            x_f = self.car_x + dists_f * np.cos(xy_angles_f_rad)
            y_f = self.car_y + dists_f * np.sin(xy_angles_f_rad)
            
            self.scatter_f_xy.set_offsets(np.c_[x_f, y_f])
            self.scatter_f_inflated.set_offsets(np.c_[x_f, y_f]) 
        else:
            self.scatter_f_polar.set_offsets(np.empty((0, 2))) 
            self.scatter_f_xy.set_offsets(np.empty((0, 2)))
            self.scatter_f_inflated.set_offsets(np.empty((0, 2)))
            
        angles_b, dists_b = self.last_centroids_b
        if len(angles_b) > 0:
            # Arka Sensör: Fiziksel olarak ters çevrili olduğu için 180 derece eklenir.
            polar_angles_b_rad = np.deg2rad(270 - angles_b)
            xy_angles_b_rad = np.deg2rad(angles_b + 180)
            
            self.scatter_b_polar.set_offsets(np.c_[polar_angles_b_rad, dists_b])
            
            x_b = self.car_x + dists_b * np.cos(xy_angles_b_rad)
            y_b = self.car_y + dists_b * np.sin(xy_angles_b_rad)
            
            self.scatter_b_xy.set_offsets(np.c_[x_b, y_b])
            self.scatter_b_inflated.set_offsets(np.c_[x_b, y_b]) 
        else:
            self.scatter_b_polar.set_offsets(np.empty((0, 2))) 
            self.scatter_b_xy.set_offsets(np.empty((0, 2)))
            self.scatter_b_inflated.set_offsets(np.empty((0, 2)))
        
        return self.scatter_f_polar, self.scatter_b_polar, self.scatter_f_xy, self.scatter_b_xy, self.scatter_f_inflated, self.scatter_b_inflated

    def run(self):
        self.ani = animation.FuncAnimation(self.fig, self._update_frame, frames=200, interval=50, blit=True)
        plt.tight_layout()
        plt.show()

if __name__ == "__main__":
    my_sensors = SerialSensorProvider(port='COM3') 
    my_radar = RadarApp(data_provider=my_sensors)
    my_radar.run()