#include <Servo.h>

// --- Serial protocol ---
// Raspberry Pi sends:
//   "CMD <servo_deg> <throttle>\n"
//     servo_deg: float degrees
//     throttle:  int in [-255..255]  (+ forward, - reverse)
//   "STOP\n"
//
// Arduino replies:
//   "OK\n"            (response to CMD / STOP)
//   "ENC <speed_cm_s> <total_dist_cm>\n"  (spontaneous, every ENC_REPORT_MS)
//
// Encoder: 20-hole disc on the motor shaft.
//   One revolution = 20 pulses → wheel circumference / 20 cm per pulse.
//   Speed sign follows the last throttle direction (+forward, −reverse).

// --- Steering servo constraints (must match rpi_stanley_controller.py) ---
static const int SERVO_PIN = 11;
static const float SERVO_CENTER_DEG = 90.0f;   // straight-ahead command
static const float SERVO_MIN_DEG = 65.0f;    // max left (mechanical)
static const float SERVO_MAX_DEG = 115.0f;   // max right (mechanical)
static const int SERVO_MIN_US = 500;   // adjust if needed
static const int SERVO_MAX_US = 2500;  // adjust if needed

// --- DC motor driver (assume L298N/L293D style) ---
// Adjust pins to your wiring.
static const int MOTOR_EN_PWM = 5;  // PWM pin
static const int MOTOR_IN1 = 51;
static const int MOTOR_IN2 = 52;

// --- Safety ---
static const unsigned long CMD_TIMEOUT_MS = 400;  // stop if no command arrives

// --- Wheel encoder ---
// Pin 2 = INT0 on the Mega 2560 (hardware interrupt, works at any speed).
static const int   ENCODER_PIN          = 2;
static const int   ENCODER_HOLES        = 20;
static const float WHEEL_DIAMETER_CM    = 7.0f;
static const float WHEEL_CIRC_CM        = 3.14159265f * WHEEL_DIAMETER_CM; // ≈ 21.99 cm
static const float CM_PER_PULSE         = WHEEL_CIRC_CM / ENCODER_HOLES;   // ≈ 1.10 cm
static const unsigned long ENC_REPORT_MS = 50;  // report interval in ms

volatile unsigned long g_pulseCount   = 0;  // incremented in ISR
static unsigned long   g_totalPulses  = 0;  // lifetime odometer
static unsigned long   g_lastReportMs = 0;
static int             g_lastThrottle = 0;  // used to sign the speed

void encoderISR() {
  g_pulseCount++;
}

Servo steering;
unsigned long lastCmdMs = 0;

static float clampf(float x, float lo, float hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

static int clampi(int x, int lo, int hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

static void motorStop() {
  analogWrite(MOTOR_EN_PWM, 0);
  digitalWrite(MOTOR_IN1, LOW);
  digitalWrite(MOTOR_IN2, LOW);
}

static void motorDrive(int throttle) {
  throttle = clampi(throttle, -255, 255);
  g_lastThrottle = throttle;  // remember direction for encoder sign
  int pwm = abs(throttle);
  if (pwm < 10) {  // deadband
    motorStop();
    return;
  }
  if (throttle >= 0) {
    digitalWrite(MOTOR_IN1, HIGH);
    digitalWrite(MOTOR_IN2, LOW);
  } else {
    digitalWrite(MOTOR_IN1, LOW);
    digitalWrite(MOTOR_IN2, HIGH);
  }
  analogWrite(MOTOR_EN_PWM, pwm);
}

static void setSteeringDeg(float deg) {
  deg = clampf(deg, SERVO_MIN_DEG, SERVO_MAX_DEG);
  steering.write(deg);
}

void setup() {
  Serial.begin(115200);

  pinMode(MOTOR_EN_PWM, OUTPUT);
  pinMode(MOTOR_IN1, OUTPUT);
  pinMode(MOTOR_IN2, OUTPUT);

  // Encoder: pull-up keeps the line stable between slots; trigger on
  // the rising edge (slot opening) for one pulse per hole.
  pinMode(ENCODER_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENCODER_PIN), encoderISR, RISING);

  steering.attach(SERVO_PIN, SERVO_MIN_US, SERVO_MAX_US);
  setSteeringDeg(SERVO_CENTER_DEG);
  motorStop();

  lastCmdMs       = millis();
  g_lastReportMs  = millis();
}

void loop() {
  // Safety timeout
  if (millis() - lastCmdMs > CMD_TIMEOUT_MS) {
    motorStop();
    setSteeringDeg(SERVO_CENTER_DEG);
  }

  // --- Encoder speed report (every ENC_REPORT_MS) ---
  unsigned long nowMs = millis();
  if (nowMs - g_lastReportMs >= ENC_REPORT_MS) {
    // Snapshot the ISR counter atomically.
    noInterrupts();
    unsigned long pulses = g_pulseCount;
    g_pulseCount = 0;
    interrupts();

    float dt_s       = (nowMs - g_lastReportMs) / 1000.0f;
    g_lastReportMs   = nowMs;
    g_totalPulses   += pulses;

    float speed = (pulses * CM_PER_PULSE) / dt_s;
    if (g_lastThrottle < 0) speed = -speed;  // reverse

    float dist = g_totalPulses * CM_PER_PULSE;

    Serial.print("ENC ");
    Serial.print(speed, 2);
    Serial.print(' ');
    Serial.println(dist, 2);
  }

  if (!Serial.available()) return;

  String line = Serial.readStringUntil('\n');
  line.trim();
  if (line.length() == 0) return;

  if (line.equals("STOP")) {
    motorStop();
    setSteeringDeg(SERVO_CENTER_DEG);
    lastCmdMs = millis();
    Serial.println("OK");
    return;
  }

  if (line.startsWith("CMD ")) {
    // Parse: CMD servo throttle
    // Example: CMD 78.5 150
    int firstSpace = line.indexOf(' ');
    int secondSpace = line.indexOf(' ', firstSpace + 1);
    if (secondSpace < 0) return;

    String sServo = line.substring(firstSpace + 1, secondSpace);
    String sThr = line.substring(secondSpace + 1);

    float servoDeg = sServo.toFloat();
    int throttle = sThr.toInt();

    setSteeringDeg(servoDeg);
    motorDrive(throttle);
    lastCmdMs = millis();
    Serial.println("OK");
    return;
  }
}

