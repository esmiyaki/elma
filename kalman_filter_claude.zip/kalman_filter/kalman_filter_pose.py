"""
kalman_filter_pose.py — EKF pose tracker fusing AprilTag + wheel encoder.

Drop-in wrapper around AprilTagMapPoseTracker.  Call update() in a loop;
it returns the same dict shape as AprilTagMapPoseTracker.update() plus two
extra fields: ``speed_cm_s`` and ``odometry_cm``.

---------------------------------------------------------------------------
EKF design
---------------------------------------------------------------------------
State  X = [x_cm, y_cm, v_cm_s, yaw_rad]   (4-vector)
  x_cm, y_cm   map-frame position  (East+, North+), same as apriltag_pose
  v_cm_s       forward speed, signed  (+forward, −reverse)
  yaw_rad      heading in radians  (0 = North, CW positive)

Process model  (predict step, constant heading / constant speed):
  x'   = x + v · sin(yaw) · dt
  y'   = y + v · cos(yaw) · dt
  v'   = v
  yaw' = yaw

Process Jacobian  F = ∂f/∂X:
  [[1, 0,  sin(yaw)·dt,  v·cos(yaw)·dt ],
   [0, 1,  cos(yaw)·dt, −v·sin(yaw)·dt],
   [0, 0,  1,            0             ],
   [0, 0,  0,            1             ]]

Measurements:
  Encoder  →  z = v              H_enc = [[0, 0, 1, 0]]
  AprilTag →  z = [x, y, yaw]   H_tag = [[1,0,0,0],[0,1,0,0],[0,0,0,1]]

Yaw wrap-around is handled in the AprilTag innovation: the residual is
normalized to (−π, π] before the update so yaw never jumps through ±180°.

---------------------------------------------------------------------------
Serial protocol (shared port)
---------------------------------------------------------------------------
Arduino sends two line types on the same USB serial port:
  "OK\n"                   — response to CMD / STOP commands
  "ENC <speed> <dist>\n"  — spontaneous encoder report (every 50 ms)

SharedSerialReader runs a background thread that demuxes these lines.
ENC lines update the speed buffer; everything else goes into a response
Queue that the motor controller can read from.

Typical usage
---------------------------------------------------------------------------
    from kalman_filter_pose import KalmanPoseTracker

    tracker = KalmanPoseTracker(serial_port='/dev/ttyACM0')
    try:
        while True:
            pose = tracker.update()
            if pose:
                print(pose['x_cm'], pose['y_cm'], pose['yaw_deg'],
                      pose['speed_cm_s'])
    finally:
        tracker.close()

Sharing the serial port with the existing motor controller
---------------------------------------------------------------------------
    reader  = SharedSerialReader('/dev/ttyACM0', baud=115200)
    tracker = KalmanPoseTracker(shared_reader=reader)
    # motor controller uses reader.write(b'CMD 90 150\\n') and
    # reader.response_queue to read 'OK' lines.
"""

import math
import queue
import threading
import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import serial

from apriltag_pose import AprilTagMapPoseTracker, normalize_angle_deg_0_360


# ---------------------------------------------------------------------------
# Tunable noise parameters
# ---------------------------------------------------------------------------

# Process noise standard deviations (per second, continuous-time-like)
_Q_POS_CM_PER_S   = 2.0    # position drift from unmodelled accelerations
_Q_V_CM_PER_S2    = 8.0    # speed changes (throttle transients)
_Q_YAW_RAD_PER_S  = math.radians(5.0)  # heading drift (slip, turns)

# Encoder measurement noise (1-sigma, cm/s)
_R_ENC_CM_S = 2.0

# AprilTag measurement noise (1-sigma)
_R_TAG_POS_CM    = 3.0             # x and y independently
_R_TAG_YAW_RAD   = math.radians(4.0)  # yaw


# ---------------------------------------------------------------------------
# Shared serial reader
# ---------------------------------------------------------------------------

class SharedSerialReader:
    """
    Opens a serial port in a background thread and demuxes incoming lines.

    Lines starting with "ENC" are parsed and stored in ``latest_enc``.
    All other lines (e.g. "OK") are put onto ``response_queue`` for the
    motor controller to consume.
    """

    def __init__(self, port: str, baud: int = 115200, timeout: float = 0.1):
        self._ser = serial.Serial(port, baud, timeout=timeout)
        self.response_queue: queue.Queue = queue.Queue()
        self._latest_enc: Optional["_EncSample"] = None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._reader, daemon=True)
        self._thread.start()

    # -- public API ----------------------------------------------------------

    @property
    def latest_enc(self) -> Optional["_EncSample"]:
        with self._lock:
            return self._latest_enc

    def write(self, data: bytes) -> None:
        self._ser.write(data)

    def reset_buffers(self) -> None:
        """Flush Arduino's pending output and clear the OS receive buffer."""
        self._ser.reset_input_buffer()
        self._ser.reset_output_buffer()

    def close(self) -> None:
        self._stop.set()
        self._thread.join(timeout=2.0)
        self._ser.close()

    # -- internal ------------------------------------------------------------

    def _reader(self) -> None:
        while not self._stop.is_set():
            try:
                raw = self._ser.readline()
            except serial.SerialException:
                break
            if not raw:
                continue
            line = raw.decode("ascii", errors="ignore").strip()
            if line.startswith("ENC"):
                sample = _EncSample.parse(line)
                if sample is not None:
                    with self._lock:
                        self._latest_enc = sample
            elif line:
                try:
                    self.response_queue.put_nowait(line)
                except queue.Full:
                    pass


@dataclass
class _EncSample:
    speed_cm_s: float
    odometry_cm: float
    timestamp: float = field(default_factory=time.perf_counter)

    @staticmethod
    def parse(line: str) -> Optional["_EncSample"]:
        # Expected format: "ENC <speed_cm_s> <total_dist_cm>"
        parts = line.split()
        if len(parts) != 3:
            return None
        try:
            return _EncSample(float(parts[1]), float(parts[2]))
        except ValueError:
            return None


# ---------------------------------------------------------------------------
# EKF implementation
# ---------------------------------------------------------------------------

def _wrap_pi(a: float) -> float:
    return (a + math.pi) % (2.0 * math.pi) - math.pi


class _EKF:
    """
    4-state EKF: X = [x_cm, y_cm, v_cm_s, yaw_rad].

    All angles are in radians internally; convert at the boundary.
    """

    def __init__(self) -> None:
        self.X = np.zeros(4)          # [x, y, v, yaw]
        self.P = np.eye(4) * 1e6     # large initial uncertainty
        self._initialised = False

    def initialise(self, x_cm: float, y_cm: float,
                   v_cm_s: float, yaw_rad: float) -> None:
        self.X[:] = [x_cm, y_cm, v_cm_s, yaw_rad]
        self.P = np.diag([5.0**2, 5.0**2, 5.0**2, math.radians(10.0)**2])
        self._initialised = True

    @property
    def initialised(self) -> bool:
        return self._initialised

    # ---- predict -----------------------------------------------------------

    def predict(self, dt: float) -> None:
        if not self._initialised or dt <= 0:
            return
        x, y, v, yaw = self.X
        sy, cy = math.sin(yaw), math.cos(yaw)

        # Nonlinear propagation
        self.X[0] = x + v * sy * dt
        self.X[1] = y + v * cy * dt
        # self.X[2] = v  (unchanged)
        # self.X[3] = yaw (unchanged)

        # Jacobian
        F = np.array([
            [1, 0,  sy * dt,  v * cy * dt],
            [0, 1,  cy * dt, -v * sy * dt],
            [0, 0,  1,        0           ],
            [0, 0,  0,        1           ],
        ])

        # Discrete process noise (scaled by dt)
        q_pos = (_Q_POS_CM_PER_S * dt) ** 2
        q_v   = (_Q_V_CM_PER_S2  * dt) ** 2
        q_yaw = (_Q_YAW_RAD_PER_S * dt) ** 2
        Q = np.diag([q_pos, q_pos, q_v, q_yaw])

        self.P = F @ self.P @ F.T + Q

    # ---- encoder measurement update ----------------------------------------

    def update_encoder(self, v_meas: float) -> None:
        if not self._initialised:
            return
        H = np.array([[0.0, 0.0, 1.0, 0.0]])
        R = np.array([[_R_ENC_CM_S ** 2]])
        self._standard_update(H, np.array([v_meas - self.X[2]]), R)

    # ---- AprilTag measurement update ---------------------------------------

    def update_apriltag(self, x_cm: float, y_cm: float, yaw_rad: float) -> None:
        if not self._initialised:
            return
        H = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 0, 1],
        ])
        z = np.array([x_cm, y_cm, yaw_rad])
        h = np.array([self.X[0], self.X[1], self.X[3]])
        innov = z - h
        innov[2] = _wrap_pi(innov[2])   # yaw wrap-around

        R = np.diag([
            _R_TAG_POS_CM ** 2,
            _R_TAG_POS_CM ** 2,
            _R_TAG_YAW_RAD ** 2,
        ])
        self._standard_update(H, innov, R)

    # ---- generic update ----------------------------------------------------

    def _standard_update(self, H: np.ndarray, innov: np.ndarray,
                         R: np.ndarray) -> None:
        S  = H @ self.P @ H.T + R
        K  = self.P @ H.T @ np.linalg.inv(S)
        self.X = self.X + K @ innov
        self.P = (np.eye(4) - K @ H) @ self.P

    # ---- accessors ---------------------------------------------------------

    @property
    def x_cm(self) -> float:
        return float(self.X[0])

    @property
    def y_cm(self) -> float:
        return float(self.X[1])

    @property
    def v_cm_s(self) -> float:
        return float(self.X[2])

    @property
    def yaw_deg(self) -> float:
        return float(normalize_angle_deg_0_360(math.degrees(self.X[3])))


# ---------------------------------------------------------------------------
# Public wrapper
# ---------------------------------------------------------------------------

class KalmanPoseTracker:
    """
    EKF pose tracker that fuses AprilTag absolute fixes with wheel encoder speed.

    Parameters
    ----------
    serial_port : str
        Path to the Arduino serial device (e.g. '/dev/ttyACM0').
        Ignored if ``shared_reader`` is provided.
    baud_rate : int
        Serial baud rate (must match Arduino sketch, default 115200).
    shared_reader : SharedSerialReader, optional
        Pre-created shared reader; use this when the motor controller also
        needs to read from the same port.
    tag_tracker_kwargs : dict, optional
        Keyword arguments forwarded to AprilTagMapPoseTracker.__init__().
    """

    def __init__(
        self,
        serial_port: str = "/dev/ttyACM0",
        baud_rate: int = 115200,
        shared_reader: Optional[SharedSerialReader] = None,
        tag_tracker_kwargs: Optional[dict] = None,
    ) -> None:
        # Serial reader
        if shared_reader is not None:
            self._reader = shared_reader
            self._owns_reader = False
        else:
            self._reader = SharedSerialReader(serial_port, baud_rate)
            self._owns_reader = True

        # AprilTag tracker (opens cameras)
        self._tag_tracker = AprilTagMapPoseTracker(**(tag_tracker_kwargs or {}))

        # EKF
        self._ekf = _EKF()
        self._last_t = time.perf_counter()

        # Cache the last encoder sample we consumed so we don't apply the
        # same measurement twice.
        self._last_enc_ts: float = -1.0

    # ---- public API --------------------------------------------------------

    def update(self) -> Optional[dict]:
        """
        Run one EKF cycle.

        Steps:
          1. Predict forward using elapsed time.
          2. Apply encoder speed measurement (if a new sample arrived).
          3. Query AprilTag tracker; apply measurement update if a tag was seen.
          4. Return the filtered pose dict (or None if EKF not yet initialised).

        Return dict fields (backward-compatible with AprilTagMapPoseTracker):
            x_cm, y_cm, yaw_deg, tag_id, camera, distance_cm,
            n_tags, fused, reproj_error_px,
            speed_cm_s   (new — filtered forward speed),
            odometry_cm  (new — total distance travelled)
        """
        now = time.perf_counter()
        dt  = now - self._last_t
        self._last_t = now

        # 1. Predict
        self._ekf.predict(dt)

        # 2. Encoder update
        enc = self._reader.latest_enc
        odometry_cm = 0.0
        if enc is not None and enc.timestamp != self._last_enc_ts:
            self._last_enc_ts = enc.timestamp
            odometry_cm = enc.odometry_cm
            if self._ekf.initialised:
                self._ekf.update_encoder(enc.speed_cm_s)
            else:
                # Can't initialise from speed alone — just store odometry.
                pass

        # 3. AprilTag update
        tag_pose = self._tag_tracker.update()
        if tag_pose is not None:
            x_tag = tag_pose["x_cm"]
            y_tag = tag_pose["y_cm"]
            yaw_tag_rad = math.radians(tag_pose["yaw_deg"])

            if not self._ekf.initialised:
                # First fix: bootstrap EKF state from AprilTag + zero speed.
                v0 = enc.speed_cm_s if enc is not None else 0.0
                self._ekf.initialise(x_tag, y_tag, v0, yaw_tag_rad)
            else:
                self._ekf.update_apriltag(x_tag, y_tag, yaw_tag_rad)

        if not self._ekf.initialised:
            return None

        # 4. Build output dict
        out: dict = {
            "x_cm":           self._ekf.x_cm,
            "y_cm":           self._ekf.y_cm,
            "yaw_deg":        self._ekf.yaw_deg,
            "speed_cm_s":     self._ekf.v_cm_s,
            "odometry_cm":    odometry_cm,
        }

        # Carry over AprilTag metadata when available.
        if tag_pose is not None:
            for key in ("tag_id", "camera", "distance_cm",
                        "n_tags", "fused", "reproj_error_px"):
                if key in tag_pose:
                    out[key] = tag_pose[key]

        return out

    @property
    def latest_speed_cm_s(self) -> float:
        """Current EKF-filtered forward speed in cm/s."""
        return self._ekf.v_cm_s

    def close(self) -> None:
        self._tag_tracker.close()
        if self._owns_reader:
            self._reader.close()


# ---------------------------------------------------------------------------
# Quick smoke-test (no real hardware needed — mocks the tracker + serial)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    print("kalman_filter_pose.py — EKF state definitions OK")
    ekf = _EKF()
    ekf.initialise(100.0, 100.0, 20.0, math.radians(0.0))
    for _ in range(10):
        ekf.predict(0.05)
    ekf.update_encoder(19.5)
    ekf.update_apriltag(100.3, 110.1, math.radians(1.0))
    print(f"  x={ekf.x_cm:.2f} cm  y={ekf.y_cm:.2f} cm  "
          f"v={ekf.v_cm_s:.2f} cm/s  yaw={ekf.yaw_deg:.2f}°")
    print("Smoke-test passed.")
