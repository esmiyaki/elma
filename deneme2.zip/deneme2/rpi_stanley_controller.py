import json
import math
import time

import serial

from apriltag_pose import AprilTagMapPoseTracker


def wrap_pi(a: float) -> float:
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def load_path(path_json_path: str):
    with open(path_json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    pts = data["points"]
    return data, pts


def nearest_index(points, x_cm, y_cm, start_idx=0, window=400):
    """
    Find nearest point index in a sliding window for speed.
    """
    n = len(points)
    if n == 0:
        return 0
    i0 = max(0, int(start_idx))
    i1 = min(n, i0 + int(window))
    best_i = i0
    best_d2 = float("inf")
    for i in range(i0, i1):
        dx = points[i]["x_cm"] - x_cm
        dy = points[i]["y_cm"] - y_cm
        d2 = dx * dx + dy * dy
        if d2 < best_d2:
            best_d2 = d2
            best_i = i
    return best_i


def stanley_control(points, pose, idx_near, k=1.2, softening=30.0):
    """
    Stanley controller in map frame.

    Path yaw is expected to be in standard math coordinates (0=+X east, CCW+).
    pose yaw is expected in the same convention.

    Reverse handling:
      - if point direction == -1, treat the vehicle heading as yaw+pi for control.
      - keep cross-track sign consistent with that effective heading.

    Returns:
      (steer_cmd_rad, target_idx, direction)
    """
    n = len(points)
    idx = clamp(idx_near, 0, n - 1)
    p = points[int(idx)]

    tx = float(p["x_cm"])
    ty = float(p["y_cm"])
    tyaw = float(p["yaw_rad"])
    direction = int(p.get("direction", 1))

    x = float(pose["x_cm"])
    y = float(pose["y_cm"])
    yaw = float(pose["yaw_rad"])

    # Effective heading depending on gear
    yaw_eff = wrap_pi(yaw + (math.pi if direction < 0 else 0.0))

    # Heading error
    heading_err = wrap_pi(tyaw - yaw_eff)

    # Cross-track error sign using path tangent normal (left normal).
    # For direction=-1, tangent is opposite, so normal flips automatically by adding pi to tyaw.
    tyaw_eff = wrap_pi(tyaw + (math.pi if direction < 0 else 0.0))
    dx = x - tx
    dy = y - ty
    left_nx = -math.sin(tyaw_eff)
    left_ny = math.cos(tyaw_eff)
    cte = dx * left_nx + dy * left_ny  # +: vehicle is left of path

    # Use nominal speed magnitude (cm/s) for Stanley term; softening avoids blow-up near zero.
    v = 40.0
    cte_term = math.atan2(k * cte, (v + softening))

    steer = heading_err + cte_term
    steer = wrap_pi(steer)
    return steer, int(idx), direction


def main():
    # --- Config ---
    PATH_FILE = "planned_path.json"
    SERIAL_PORT = "/dev/ttyACM0"  # adjust if needed
    BAUD = 115200

    LOOP_HZ = 15.0
    POSE_TIMEOUT_S = 0.7
    CMD_TIMEOUT_S = 0.5

    # steering mapping (servo)
    SERVO_CENTER_DEG = 75.0
    SERVO_MAX_DELTA_DEG = 25.0
    MAX_STEER_RAD_FOR_SERVO = math.radians(35.0)  # planner max; maps to +-25deg at servo

    # throttle mapping
    THROTTLE_FWD = 160  # 0..255
    THROTTLE_REV = 140  # 0..255 (often safer a bit lower)
    SLOWDOWN_DIST_CM = 25.0

    # --- Load path ---
    meta, points = load_path(PATH_FILE)
    if not points:
        raise RuntimeError("Path file has no points.")

    print(f"[OK] Loaded {len(points)} path points from {PATH_FILE}")

    # --- Start tracker + serial ---
    tracker = AprilTagMapPoseTracker()
    ser = serial.Serial(SERIAL_PORT, BAUD, timeout=0.05)
    ser.write(b"STOP\n")

    last_pose_t = 0.0
    last_cmd_t = 0.0
    idx = 0
    last_pose = None

    dt = 1.0 / LOOP_HZ
    try:
        while True:
            t0 = time.perf_counter()

            # Pose update
            p = tracker.update()
            if p is not None:
                # Convert apriltag yaw to controller yaw convention:
                # apriltag yaw: 0°=+Y, CCW+
                # controller yaw: 0 rad=+X, CCW+
                yaw_rad = wrap_pi(math.radians(float(p["yaw_deg"])) + (math.pi / 2.0))
                pose = {"x_cm": float(p["x_cm"]), "y_cm": float(p["y_cm"]), "yaw_rad": yaw_rad}
                last_pose = pose
                last_pose_t = time.perf_counter()

            now = time.perf_counter()
            if last_pose is None or (now - last_pose_t) > POSE_TIMEOUT_S:
                # Fail-safe stop if pose is stale
                if (now - last_cmd_t) > CMD_TIMEOUT_S:
                    ser.write(b"STOP\n")
                    last_cmd_t = now
                time.sleep(max(0.0, dt - (time.perf_counter() - t0)))
                continue

            # Progress along path by nearest point in a forward window
            idx = nearest_index(points, last_pose["x_cm"], last_pose["y_cm"], start_idx=idx, window=500)

            steer_rad, idx, direction = stanley_control(points, last_pose, idx)

            # Slow down near final target
            gx = float(points[-1]["x_cm"])
            gy = float(points[-1]["y_cm"])
            dist_goal = math.hypot(last_pose["x_cm"] - gx, last_pose["y_cm"] - gy)
            scale = clamp(dist_goal / SLOWDOWN_DIST_CM, 0.2, 1.0)

            throttle = int((THROTTLE_FWD if direction > 0 else THROTTLE_REV) * scale)
            throttle = throttle if direction > 0 else -throttle

            # Map steering rad -> servo degrees with constraints
            steer_rad = clamp(steer_rad, -MAX_STEER_RAD_FOR_SERVO, MAX_STEER_RAD_FOR_SERVO)
            servo_deg = SERVO_CENTER_DEG + (steer_rad / MAX_STEER_RAD_FOR_SERVO) * SERVO_MAX_DELTA_DEG
            servo_deg = clamp(servo_deg, SERVO_CENTER_DEG - SERVO_MAX_DELTA_DEG, SERVO_CENTER_DEG + SERVO_MAX_DELTA_DEG)

            # Send command
            line = f"CMD {servo_deg:.1f} {throttle}\n".encode("ascii")
            ser.write(line)
            last_cmd_t = time.perf_counter()

            # End condition
            if dist_goal < 3.0 and idx > len(points) - 30:
                ser.write(b"STOP\n")
                break

            # loop timing
            elapsed = time.perf_counter() - t0
            time.sleep(max(0.0, dt - elapsed))

    finally:
        try:
            ser.write(b"STOP\n")
        except Exception:
            pass
        try:
            ser.close()
        except Exception:
            pass
        try:
            tracker.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()

